import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:women_safety_app/db/share_pref.dart';
import 'package:carousel_slider/carousel_slider.dart'; // Import for CarouselSlider
import 'package:carousel_slider/carousel_controller.dart' as carousel_slider; // Import with a prefix for CarouselController
// import 'package:women_safety_app/child/bottom_screens/child_home_page.dart';

import 'package:women_safety_app/utils/flutter_background_services.dart';
import 'child/bottom_page.dart';
import 'package:carousel_slider/carousel_controller.dart' as carousel_slider;

final navigatorkey = GlobalKey<ScaffoldMessengerState>();

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  await MySharedPrefference.init();
  await initializeService();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        title: 'Flutter Demo',
        // scaffoldMessengerKey: navigatorkey,
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          textTheme: GoogleFonts.firaSansTextTheme(
            Theme.of(context).textTheme,
          ),
          primarySwatch: Colors.blue,
        ),
        home: BottomPage());

  }
}


class MyCarousel extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Create an instance of CarouselController using the prefixed import
    final carouselController = carousel_slider.CarouselController();

    return Scaffold(
      appBar: AppBar(title: Text("Carousel Example")),
      body: Center(
        child: CarouselSlider(
          carouselController: carouselController, // Use the controller here
          options: CarouselOptions(
            height: 400,
            autoPlay: true,
          ),
          items: [
            // Add your carousel items here
            Container(color: Colors.red, width: 100, height: 100),
            Container(color: Colors.green, width: 100, height: 100),
            Container(color: Colors.blue, width: 100, height: 100),
          ],
        ),
      ),
    );
  }
}




// class CheckAuth extends StatelessWidget {
//   // const CheckAuth({Key? key}) : super(key: key);

//   checkData() {
//     if (MySharedPrefference.getUserType() == 'parent') {}
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold();
//   }
// }
